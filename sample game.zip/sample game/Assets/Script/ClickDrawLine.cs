﻿using UnityEngine;
using System.Collections;

public class ClickDrawLine: MonoBehaviour
{

	public GameObject linePrefab;//オブジェクト指定
	public float lineLength = 0.1f;//線の長さ
	public float lineWidth = 0.2f;//線の太さ
	private Vector3 touchPos;//画面をタッチした際の座標
	
	void Start(){//起動時
	}

	void Update (){//毎フレーム実行
		drawLine ();//線を描く
	}

	void drawLine(){

		if(Input.GetMouseButtonDown(0))//もしマウスが押されたら
		{
			touchPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);//マウスの座標取得（ワールド座標）
			touchPos.z=0;//奥行きを無くす
			Debug.Log("click" + touchPos);//タッチできているか
		}

		if(Input.GetMouseButton(0))//マウスが押されている間
		{

			Vector3 startPos = touchPos;//始点の取得
			Vector3 endPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);//マウスの座標取得（ワールド座標）
			endPos.z=0;//奥行きは無くす
			if((endPos-startPos).magnitude > lineLength){//もし長さが最低限を超えていたら
				GameObject obj = Instantiate(linePrefab, transform.position, transform.rotation) as GameObject;//オブジェクトの配置
				obj.transform.position = (startPos+endPos)/2;//
				obj.transform.right = (endPos-startPos).normalized;//正規化

				obj.transform.localScale = new Vector3( (endPos-startPos).magnitude, lineWidth , lineWidth );

				obj.transform.parent = this.transform;

				touchPos = endPos;
			}
		}

	}
}
