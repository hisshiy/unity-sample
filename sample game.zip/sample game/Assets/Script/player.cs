﻿using UnityEngine;
using System.Collections;

public class player : MonoBehaviour {
	Rigidbody2D user;//Rgidbody:GameObject が物理特性の制御下で動作するようにする
	public int speed = 0;

	void Start () {//プレイヤーの実行時に一度だけ呼ばれる
		//GetComponentの処理をキャッシュしておく
		user = GetComponent<Rigidbody2D>();
	}

	void FixedUpdate () {//毎フレームごとに呼ばれる RIgidbodyを扱う場合はUpdateの代わりにFixedUpdateを使用する
	}

	void OnCollisionStay2D(Collision2D collision){//他のColliderやRigidbodyオブジェクトに触れた時に呼び出される
		//velocity:速度
		//x方向へspeed分移動させる
		user.velocity = new Vector2(speed, user.velocity.y);
	}
}
