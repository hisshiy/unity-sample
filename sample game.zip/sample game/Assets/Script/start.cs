﻿using UnityEngine;
using System.Collections;

public class start : MonoBehaviour {

		public void SceneLoad (){
			Application.LoadLevel ("game");
		}
}
