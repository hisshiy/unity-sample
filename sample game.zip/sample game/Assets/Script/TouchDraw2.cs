﻿using UnityEngine;
using System.Collections.Generic;

public class TouchDraw2 : MonoBehaviour {

	public GameObject linePrefab2;
	public float lineLength = 0.2f;
	public float lineWidth = 0.1f;
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		if (Input.touchCount > 0) {//タッチされたかどうか
			Touch touch = Input.GetTouch (0);
			Vector3 DeltaPosition = Input.GetTouch (0).deltaPosition;
			Vector3 tapStart;
			Vector3 tapFinish;
			if (touch.phase == TouchPhase.Began) {//タッチ開始
			}
			if (touch.phase == TouchPhase.Moved) {//タッチ移動
				tapStart = Camera.main.ScreenToWorldPoint(touch.position);//マウスの座標取得（ワールド座標）
				tapStart.z=0;//奥行きを無くす
				tapStart.x = tapStart.x + 48;//タッチ位置調整
				tapFinish = tapStart - DeltaPosition;
				GameObject obj = Instantiate (linePrefab2, transform.position, transform.rotation) as GameObject;

				//obj.transform.localPosition = tapStart;
				//obj.transform.right = tapStart.normalized;
				obj.transform.localPosition = tapStart;
				obj.transform.right = (tapFinish-tapStart).normalized;
				obj.transform.parent = this.transform;
			}
			if (touch.phase == TouchPhase.Ended) {//タッチ終了
			}

		}
	}
}
